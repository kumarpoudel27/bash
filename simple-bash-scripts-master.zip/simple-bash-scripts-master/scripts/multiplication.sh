#!/usr/bin/env bash
echo -n "Enter the First Number: "
read a
echo -n "Enter the Second Number: "
read b
echo "$a * $b = $((a * b))"
