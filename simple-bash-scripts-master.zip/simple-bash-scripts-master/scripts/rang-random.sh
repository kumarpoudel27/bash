#!/usr/bin/env bash

shuf -i "$1-$2" -n 1
